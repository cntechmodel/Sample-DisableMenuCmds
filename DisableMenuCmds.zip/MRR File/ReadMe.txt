You MUST place the .mrr file in the ProjectWise "bin" directory otherwise ProjectWise Explorer will NOT try to use it.

If anything is missing or incorrect in the .mrr file, ProjectWise Explorer does not inform the user of a problem, it is simply ignored.